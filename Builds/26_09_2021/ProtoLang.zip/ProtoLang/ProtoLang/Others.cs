﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProtoLang
{
    
    /*
    public enum SpecialType
    {
        If,
        While
    }
    class Special
    {
        public int IfConditionindex;
        public int Endindex;
        public SpecialType Type;
    }
    */
}
