﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProtoLang
{
    public enum VariableType
    {
        @undefined,
        @int,
        @float,
        @string
    }

    class VariableData
    {
        public int @int;
        public float @float;
        public string @string;

        public VariableData()
        {
            @int = 0;
            @float = 0;
            @string = "";
        }



        public VariableData Clone()
        {
            return (VariableData)this.MemberwiseClone();
        }
    }

    class Variable
    {
        public string Name;
        public VariableType Type;
        public VariableData Data;


        public Variable(string name)
        {
            Name = name;
            Type = VariableType.undefined;
            Data = new VariableData();
        }
        public object GetData()
        {
            if (Type == VariableType.@int)
            {
                return Data.@int;
            }
            if (Type == VariableType.@float)
            {
                return Data.@float;
            }
            if (Type == VariableType.@string)
            {
                return Data.@string;
            }
            return null;
        }
        public string GetStringData()
        {
            if (Type == VariableType.@int)
            {
                return Data.@int.ToString();
            }
            if (Type == VariableType.@float)
            {
                return Data.@float.ToString();
            }
            if (Type == VariableType.@string)
            {
                return Data.@string;
            }
            return "";
        }

        public Variable Copy()
        {
            Variable temp = (Variable)this.MemberwiseClone();

            temp.Data = temp.Data.Clone();

            return temp;
        }

    }
}
