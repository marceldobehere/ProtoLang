﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProtoLang
{
    class Scope
    {
        public List<Variable> Variables;
        //public List<Special> Specials;

        public int Startindex;
        public int Layer;
        public int Endindex;
        public int OldIndex;

        public Scope(int start, int end, int layer, int index)
        {
            Variables = new List<Variable>();
            //Specials = new List<Special>();
            Startindex = start;
            Endindex = end;
            Layer = layer;
            OldIndex = index;
        }

        /*
        public void LoadSpecials()
        {

        }
        */
    }
}
