﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;

namespace ProtoLang
{
    public enum CommandType
    {
        Undefined,
        None,
        NewLine,
        Tab,
        Semicolon,
        Space,
        @string,
        @int,
        @float,
        Instruction,
        RoundBracketOpen,
        RoundBracketClose,
        ScopeOpen,
        ScopeClose,
        Operator,
        VariableName,
        Value
    }
    public static class Commands
    {
        public static Dictionary<string, List<(int, CommandType)>> CommandList;
        public static Dictionary<string, int> CommandPriorities;
        public static List<int> ExistingCommandPriorities;
        public static List<string> Operators;
        public static void Init()
        {
            Operators = new List<string>() { "!=", "<", ">", "<=", ">=" };
            CommandList = new Dictionary<string, List<(int offset, CommandType type)>>()
            {
                //{"", new List<(int, CommandType)>(){ } },
                {"int", new List<(int, CommandType)>(){(1, CommandType.VariableName) } },
                {"float", new List<(int, CommandType)>(){(1, CommandType.VariableName) } },
                {"string", new List<(int, CommandType)>(){(1, CommandType.VariableName) } },
                {"var", new List<(int, CommandType)>(){(1, CommandType.VariableName) } },
                {"=", new List<(int, CommandType)>(){(-1, CommandType.VariableName), (1, CommandType.Value) } },
                {"print", new List<(int, CommandType)>(){(2, CommandType.Value) } },
                {"if", new List<(int, CommandType)>(){ (2, CommandType.Value), (3, CommandType.Operator), (4, CommandType.Value) } },
                {"+", new List<(int, CommandType)>(){(-1, CommandType.Value), (1, CommandType.Value) } },
                {"-", new List<(int, CommandType)>(){(-1, CommandType.Value), (1, CommandType.Value) } },
                {"*", new List<(int, CommandType)>(){(-1, CommandType.Value), (1, CommandType.Value) } },
                {"/", new List<(int, CommandType)>(){(-1, CommandType.Value), (1, CommandType.Value) } },
                {"%", new List<(int, CommandType)>(){(-1, CommandType.Value), (1, CommandType.Value) } },
                {"read", new List<(int, CommandType)>(){(2, CommandType.VariableName) } },
                {"end", new List<(int, CommandType)>(){} }

            };
            CommandPriorities = new Dictionary<string, int>()
            {
                {"int", 5},
                {"float", 5},
                {"string", 5},
                {"var", 5},
                {"=", 1},
                {"print", 1},
                {"if", 1},
                {"+", 10},
                {"-", 10},
                {"*", 11},
                {"/", 11},
                {"%", 11},
                {"read", 1},
                {"end", 1}
            };
            ExistingCommandPriorities = new List<int>()
            {
                11,10,5,1
            };
        }


        public static void RemoveSingleProgramDataInstance(int INDEXTOREMOVE, ref int startindex, ref int endindex, ref int currentindex)
        {
            Main_Program.ProgramData.RemoveAt(INDEXTOREMOVE);



            for (int i = 0; i < Main_Program.ScopePoints.Count; i++)
            {
                if (Main_Program.ScopePoints.ElementAt(i).Key >= INDEXTOREMOVE)
                {
                    int tempstart = Main_Program.ScopePoints.ElementAt(i).Key;
                    int tempend = Main_Program.ScopePoints.ElementAt(i).Value;
                    Main_Program.ScopePoints.Remove(Main_Program.ScopePoints.ElementAt(i).Key);
                    Main_Program.ScopePoints.Add(tempstart - 1, tempend - 1);
                }
                else if (Main_Program.ScopePoints.ElementAt(i).Value >= INDEXTOREMOVE)
                {
                    Main_Program.ScopePoints[Main_Program.ScopePoints.ElementAt(i).Key]--;
                }
            }
            for (int i = 0; i < Main_Program.Scopes.Count; i++)
            {
                if (Main_Program.Scopes[i].OldIndex >= INDEXTOREMOVE)
                {
                    Main_Program.Scopes[i].OldIndex--;
                }
                if (Main_Program.Scopes[i].Startindex >= INDEXTOREMOVE)
                {
                    Main_Program.Scopes[i].Startindex--;
                }
                if (Main_Program.Scopes[i].Endindex >= INDEXTOREMOVE)
                {
                    Main_Program.Scopes[i].Endindex--;
                }

            }

            if (startindex >= INDEXTOREMOVE)
            {
                startindex--;
            }
            if (endindex >= INDEXTOREMOVE)
            {
                endindex--;
            }
            if (currentindex >= INDEXTOREMOVE)
            {
                currentindex--;
            }
            if (Main_Program.ProgramIndex >= INDEXTOREMOVE)
            {
                Main_Program.ProgramIndex--;
            }
        }


        public static void ExecuteCommand(string Command, List<(string, CommandType)> CommandData, ref int startindex, ref int endindex, ref int currentindex)
        {
            if ("+-*/%".Contains(Command))
            {

                {
                    CommandType TYPE = CommandType.@int;
                    float aa = 0, bb = 0;
                    if (Main_Program.DebugOut)
                        Console.WriteLine("MATH");
                    string a;
                    string b;
                    if (CommandData[0].Item2 == CommandType.VariableName)
                    {
                        a = Main_Program.GetVariablefromName(CommandData[0].Item1).GetStringData();
                    }
                    else
                    {
                        a = CommandData[0].Item1;
                    }
                    if (CommandData[1].Item2 == CommandType.VariableName)
                    {
                        b = Main_Program.GetVariablefromName(CommandData[1].Item1).GetStringData();
                    }
                    else
                    {
                        b = CommandData[1].Item1;
                    }
                    if (Main_Program.DebugOut)
                        Console.WriteLine($"MATH with two nums nums {CommandData[0]} {Command} {CommandData[1]}");
                    {
                        if (float.TryParse(a, NumberStyles.Float, CultureInfo.InvariantCulture, out float af))
                        {
                            if (float.TryParse(b, NumberStyles.Float, CultureInfo.InvariantCulture, out float bf))
                            {
                                TYPE = CommandType.@float;
                                aa = af;
                                bb = bf;
                            }
                        }
                    }
                    {
                        if (int.TryParse(a, NumberStyles.Integer, CultureInfo.InvariantCulture, out int af))
                        {
                            if (int.TryParse(b, NumberStyles.Integer, CultureInfo.InvariantCulture, out int bf))
                            {
                                TYPE = CommandType.@int;
                                aa = af;
                                bb = bf;
                            }
                        }
                    }


                    float result = 0;
                    if (Command == "+")
                    {
                        result = aa + bb;
                    }
                    else if (Command == "-")
                    {
                        result = aa - bb;
                    }
                    else if (Command == "*")
                    {
                        result = aa * bb;
                    }
                    else if (Command == "/")
                    {
                        if (TYPE == CommandType.@int)
                        {
                            result = ((int)aa) / ((int)bb);
                        }
                        else
                        {
                            result = aa / bb;
                        }
                    }
                    else if (Command == "%")
                    {
                        if (TYPE == CommandType.@int)
                        {
                            result = ((int)aa) % ((int)bb);
                        }
                        else
                        {
                            result = aa % bb;
                        }
                    }
                    if (CommandData[0].Item2 == CommandType.@string || CommandData[1].Item2 == CommandType.@string)
                    {
                        string c1 = CommandData[0].Item1;
                        if (CommandData[0].Item2 == CommandType.VariableName)
                        {
                            c1 = Main_Program.GetVariablefromName(CommandData[0].Item1).GetStringData();
                        }
                        string c2 = CommandData[1].Item1;
                        if (CommandData[1].Item2 == CommandType.VariableName)
                        {
                            c2 = Main_Program.GetVariablefromName(CommandData[1].Item1).GetStringData();
                        }

                        RemoveSingleProgramDataInstance(currentindex - 1, ref startindex, ref endindex, ref currentindex);
                        RemoveSingleProgramDataInstance(currentindex + 1, ref startindex, ref endindex, ref currentindex);
                        Main_Program.ProgramData[currentindex] = ((c1 + c2), CommandType.@string);
                        return;
                    }
                    RemoveSingleProgramDataInstance(currentindex - 1, ref startindex, ref endindex, ref currentindex);
                    RemoveSingleProgramDataInstance(currentindex + 1, ref startindex, ref endindex, ref currentindex);
                    Main_Program.ProgramData[currentindex] = (result.ToString(), TYPE);
                }
                return;
            }
            switch (Command)
            {
                case "read":
                    {

                        int index = -1;
                        for (int i = 0; i < Main_Program.ActiveScope.Variables.Count; i++)
                        {
                            if (Main_Program.ActiveScope.Variables[i].Name == CommandData[0].Item1)
                            {
                                index = i;
                            }
                        }
                        if (index != -1)
                        {
                            Main_Program.ActiveScope.Variables[index].Data.@string = Console.ReadLine();
                            Main_Program.ActiveScope.Variables[index].Type = VariableType.@string;
                        }

                        if (Main_Program.DebugOut)
                            Console.WriteLine($"- reading into variable");
                    }
                    break;

                case "end":
                    {
                        Main_Program.Scopes = new List<Scope>();
                        Main_Program.ProgramIndex = Main_Program.ProgramData.Count;
                    }
                    break;

                case "if":
                    {
                        string a;
                        string b;
                        if (CommandData[0].Item2 == CommandType.VariableName)
                        {
                            a = Main_Program.GetVariablefromName(CommandData[0].Item1).GetStringData();
                        }
                        else
                        {
                            a = CommandData[0].Item1;
                        }
                        if (CommandData[2].Item2 == CommandType.VariableName)
                        {
                            b = Main_Program.GetVariablefromName(CommandData[2].Item1).GetStringData();
                        }
                        else
                        {
                            b = CommandData[2].Item1;
                        }

                        bool conditionmet = false;
                        if (CommandData[1].Item2 == CommandType.Operator)
                        {
                            switch (CommandData[1].Item1)
                            {
                                case "":
                                    {

                                    }
                                    break;
                                case "==":
                                    {
                                        if (a == b)
                                            conditionmet = true;
                                    }
                                    break;
                                case "!=":
                                    {
                                        if (a != b)
                                            conditionmet = true;
                                    }
                                    break;
                                case ">":
                                    {
                                        if (float.TryParse(a, NumberStyles.Float, CultureInfo.InvariantCulture, out float af))
                                        {
                                            if (float.TryParse(b, NumberStyles.Float, CultureInfo.InvariantCulture, out float bf))
                                            {
                                                if (af > bf)
                                                    conditionmet = true;
                                            }
                                        }
                                    }
                                    break;
                                case "<":
                                    {
                                        if (float.TryParse(a, NumberStyles.Float, CultureInfo.InvariantCulture, out float af))
                                        {
                                            if (float.TryParse(b, NumberStyles.Float, CultureInfo.InvariantCulture, out float bf))
                                            {
                                                if (af < bf)
                                                    conditionmet = true;
                                            }
                                        }
                                    }
                                    break;
                                case ">=":
                                    {
                                        if (float.TryParse(a, NumberStyles.Float, CultureInfo.InvariantCulture, out float af))
                                        {
                                            if (float.TryParse(b, NumberStyles.Float, CultureInfo.InvariantCulture, out float bf))
                                            {
                                                if (af >= bf)
                                                    conditionmet = true;
                                            }
                                        }
                                    }
                                    break;
                                case "<=":
                                    {
                                        if (float.TryParse(a, NumberStyles.Float, CultureInfo.InvariantCulture, out float af))
                                        {
                                            if (float.TryParse(b, NumberStyles.Float, CultureInfo.InvariantCulture, out float bf))
                                            {
                                                if (af <= bf)
                                                    conditionmet = true;
                                            }
                                        }
                                    }
                                    break;

                            }
                        }

                        if (conditionmet)
                        {

                        }
                        else
                        {
                            while (Main_Program.ProgramData[Main_Program.ProgramIndex].type != CommandType.ScopeOpen && Main_Program.ProgramIndex < Main_Program.ProgramData.Count)
                            {
                                Main_Program.ProgramIndex++;
                            }
                            if (Main_Program.ProgramData[Main_Program.ProgramIndex].type == CommandType.ScopeOpen)
                            {
                                Main_Program.ProgramIndex = Main_Program.ScopePoints[Main_Program.ProgramIndex];
                            }
                        }
                    }
                    break;

                case "print":
                    {
                        if (Main_Program.DebugOut)
                            Console.WriteLine($"- Printing stuff {CommandData[0].Item1} - ({CommandData[0].Item2})");
                        if (CommandData[0].Item2 == CommandType.@string || CommandData[0].Item2 == CommandType.@int || CommandData[0].Item2 == CommandType.@float)
                        {
                            Console.WriteLine(CommandData[0].Item1);
                        }
                        if (CommandData[0].Item2 == CommandType.VariableName)
                        {
                            int index = -1;
                            for (int i = 0; i < Main_Program.ActiveScope.Variables.Count; i++)
                            {
                                if (Main_Program.ActiveScope.Variables[i].Name == CommandData[0].Item1)
                                {
                                    index = i;
                                }
                            }
                            if (index != -1)
                            {
                                Console.WriteLine(Main_Program.ActiveScope.Variables[index].GetData());
                            }
                        }
                    }
                    break;
                case "=":
                    {

                        int index = -1;
                        for (int i = 0; i < Main_Program.ActiveScope.Variables.Count; i++)
                        {
                            if (Main_Program.ActiveScope.Variables[i].Name == CommandData[0].Item1)
                            {
                                index = i;
                            }
                        }
                        if (index != -1)
                        {
                            if (CommandData[1].Item2 != CommandType.VariableName)
                            {
                                if (Main_Program.ActiveScope.Variables[index].Type == VariableType.@int)
                                {

                                    Main_Program.ActiveScope.Variables[index].Data.@int = int.Parse(CommandData[1].Item1, NumberStyles.Integer, CultureInfo.InvariantCulture);
                                }
                                if (Main_Program.ActiveScope.Variables[index].Type == VariableType.@float)
                                {
                                    Main_Program.ActiveScope.Variables[index].Data.@float = float.Parse(CommandData[1].Item1, NumberStyles.Float, CultureInfo.InvariantCulture);
                                }
                                if (Main_Program.ActiveScope.Variables[index].Type == VariableType.@string)
                                {
                                    Main_Program.ActiveScope.Variables[index].Data.@string = CommandData[1].Item1;
                                }
                                if (Main_Program.ActiveScope.Variables[index].Type == VariableType.undefined)
                                {
                                    if (float.TryParse(CommandData[1].Item1, NumberStyles.Float, CultureInfo.InvariantCulture, out float _f))
                                    {
                                        if (int.TryParse(CommandData[1].Item1, NumberStyles.Integer, CultureInfo.InvariantCulture, out int _i))
                                        {
                                            Main_Program.ActiveScope.Variables[index].Data.@int = int.Parse(CommandData[1].Item1, NumberStyles.Integer, CultureInfo.InvariantCulture);
                                            Main_Program.ActiveScope.Variables[index].Type = VariableType.@int;
                                        }
                                        else
                                        {
                                            Main_Program.ActiveScope.Variables[index].Data.@float = float.Parse(CommandData[1].Item1, NumberStyles.Float, CultureInfo.InvariantCulture);
                                            Main_Program.ActiveScope.Variables[index].Type = VariableType.@float;
                                        }
                                    }
                                    else
                                    {
                                        Main_Program.ActiveScope.Variables[index].Data.@string = CommandData[1].Item1;
                                        Main_Program.ActiveScope.Variables[index].Type = VariableType.@string;
                                    }
                                }
                            }
                            if (CommandData[1].Item2 == CommandType.VariableName)
                            {
                                int index2 = -1;
                                for (int i = 0; i < Main_Program.ActiveScope.Variables.Count; i++)
                                {
                                    if (Main_Program.ActiveScope.Variables[i].Name == CommandData[1].Item1)
                                    {
                                        index2 = i;
                                    }
                                }
                                if (index2 != -1)
                                {
                                    Main_Program.ActiveScope.Variables[index].Data = Main_Program.ActiveScope.Variables[index2].Data.Clone();
                                }
                            }
                        }
                    }
                    break;
                case "int":
                    {
                        Main_Program.ActiveScope.Variables.Add(new Variable(CommandData[0].Item1) { Type = VariableType.@int });
                        if (Main_Program.DebugOut)
                            Console.WriteLine($"- Adding int Variable {CommandData[0].Item1} to Scope!");
                    }
                    break;
                case "float":
                    {
                        Main_Program.ActiveScope.Variables.Add(new Variable(CommandData[0].Item1) { Type = VariableType.@float });
                        if (Main_Program.DebugOut)
                            Console.WriteLine($"- Adding float Variable {CommandData[0].Item1} to Scope!");
                    }
                    break;
                case "string":
                    {
                        Main_Program.ActiveScope.Variables.Add(new Variable(CommandData[0].Item1) { Type = VariableType.@string });
                        if (Main_Program.DebugOut)
                            Console.WriteLine($"- Adding string Variable {CommandData[0].Item1} to Scope!");
                    }
                    break;
                case "var":
                    {
                        Main_Program.ActiveScope.Variables.Add(new Variable(CommandData[0].Item1) { Type = VariableType.undefined });
                        if (Main_Program.DebugOut)
                            Console.WriteLine($"- Adding undefined Variable {CommandData[0].Item1} to Scope!");
                    }
                    break;
            }
        }
    }


}
