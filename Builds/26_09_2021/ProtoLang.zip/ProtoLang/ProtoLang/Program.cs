﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;

namespace ProtoLang
{
    class Main_Program
    {
        public static bool DebugOut;
        public static List<Scope> Scopes;
        public static string FileData;

        public static List<(string data, CommandType type)> ProgramData;
        public static int ProgramIndex;
        public static Scope ActiveScope;
        public static SortedDictionary<int, int> ScopePoints;

        static void Run()
        {
            if (DebugOut)
                Console.WriteLine();
            LoadFileIntoProgramData();
            
            if (DebugOut)
            {
                Console.WriteLine();
                Console.WriteLine("Starting Execution!");
            }
            ProgramIndex = 0;
            Scopes = new List<Scope>();
            AddScope(0, ProgramData.Count - 1, ProgramData.Count - 1);
            while (Scopes.Count > 0)
            {
                ExecuteInScope(Scopes.Last());
            }
            if (DebugOut)
                Console.WriteLine("Done...");
        }


        /*
        static void ExecuteInScope(Scope CurrentScope)
        {
            ActiveScope = Scopes.Last();
            //Console.WriteLine($"Executing start: {ProgramData[ProgramIndex]} at {ProgramIndex}");
            while (ProgramIndex < ProgramData.Count && ProgramIndex < CurrentScope.Endindex && ProgramData[ProgramIndex].type != CommandType.Instruction)
            {
                if (ProgramData[ProgramIndex].type == CommandType.ScopeOpen)
                {
                    if (DebugOut) 
                        Console.WriteLine($"Entering new Scope! {ProgramIndex}");
                    AddScope(ProgramIndex, ScopePoints[ProgramIndex]);

                    ProgramIndex++;
                    return;
                }
                ProgramIndex++;
            }
            //Console.WriteLine("Continue");
            if (!(ProgramIndex < ProgramData.Count && ProgramIndex < CurrentScope.Endindex))
            {
                if (DebugOut) 
                    Console.WriteLine("Exiting Scope!");

                RemoveScope(CurrentScope);
                return;
            }

            if (DebugOut) 
                Console.WriteLine($"Executing1: {ProgramData[ProgramIndex]} at {ProgramIndex}");
            // Execute Command

            List<(string data, CommandType type)> commandargs = new List<(string data, CommandType type)>();
            //Commands.CommandList[ProgramData[ProgramIndex].data].Count
            for (int i = 0; i < Commands.CommandList[ProgramData[ProgramIndex].data].Count; i++)
            {
                int offset = Commands.CommandList[ProgramData[ProgramIndex].data][i].Item1;
                commandargs.Add((ProgramData[ProgramIndex + offset].data, ProgramData[ProgramIndex + offset].type));
            }

            Commands.ExecuteCommand(ProgramData[ProgramIndex].data, commandargs);
            //if (DebugOut)
            //    Console.WriteLine($"Executing2: {ProgramData[ProgramIndex]} at {ProgramIndex}");


            ProgramIndex++;
        }
        */



        static void ExecuteInScope(Scope CurrentScope)
        {
            ActiveScope = Scopes.Last();
            int commandstartindex = ProgramIndex;
            //Console.WriteLine($"Executing start: {ProgramData[ProgramIndex]} at {ProgramIndex}");
            while (ProgramIndex < ProgramData.Count && ProgramIndex < CurrentScope.Endindex && ProgramData[ProgramIndex].type != CommandType.Semicolon)
            {
                if (ProgramData[ProgramIndex].type == CommandType.ScopeOpen)
                {
                    if (DebugOut)
                        Console.WriteLine($"Entering new Scope! {ProgramIndex}");
                    AddScope(ProgramIndex, ScopePoints[ProgramIndex], ScopePoints[ProgramIndex]);

                    ProgramIndex++;
                    return;
                }
                ProgramIndex++;
            }
            //Console.WriteLine("Continue");
            if (!(ProgramIndex < ProgramData.Count && ProgramIndex < CurrentScope.Endindex))
            {
                if (DebugOut)
                    Console.WriteLine("Exiting Scope!");

                RemoveScope(CurrentScope);
                return;
            }

            if (DebugOut)
                Console.WriteLine($"Executing1: {ProgramData[ProgramIndex]} at {ProgramIndex}");
            // Execute Command
            int commandendindex = ProgramIndex;



            foreach(int priority in Commands.ExistingCommandPriorities)
            {
                for (int tempindex = commandstartindex; tempindex <= commandendindex; tempindex++)
                {
                    //if (DebugOut)
                        //Console.WriteLine($"TESTING COMMAND: {tempindex} with {priority} - {commandstartindex} to {commandendindex}");
                    if (ProgramData[tempindex].type == CommandType.Instruction)
                    {
                        if (DebugOut)
                            Console.WriteLine($"TESTING PRIORITY: {ProgramData[tempindex].data} () == {priority}");
                        if (DebugOut)
                            Console.WriteLine($"- ({Commands.CommandPriorities[ProgramData[tempindex].data]})");
                        if (Commands.CommandPriorities[ProgramData[tempindex].data] == priority)
                        {
                            List<(string data, CommandType type)> commandargs = new List<(string data, CommandType type)>();
                            //Commands.CommandList[ProgramData[ProgramIndex].data].Count
                            for (int i = 0; i < Commands.CommandList[ProgramData[tempindex].data].Count; i++)
                            {
                                int offset = Commands.CommandList[ProgramData[tempindex].data][i].Item1;
                                commandargs.Add((ProgramData[tempindex + offset].data, ProgramData[tempindex + offset].type));
                            }

                            Commands.ExecuteCommand(ProgramData[tempindex].data, commandargs, ref commandstartindex, ref commandendindex, ref tempindex);
                        }
                    }
                }
            }


            ProgramIndex++;
        }







        static void AddScope(int start, int end, int currentindex)
        {
            if (Scopes.Count > 0)
            {
                int layer = Scopes.Last().Layer + 1;
                for (int i = Scopes.Count - 1; i > -1; i--)
                {
                    if (start >= Scopes[i].Startindex && end <= Scopes[i].Endindex)
                    {
                        layer = Scopes[i].Layer + 1;
                        break;
                    }
                }

                Scopes.Add(new Scope(start, end, layer, currentindex));

                for (int i = Scopes.Count - 1; i > -1; i--)
                {
                    if (Scopes[i].Layer + 1 == layer)
                    {
                        Scopes.Last().Variables.AddRange(Scopes[i].Variables);
                        break;
                    }
                }
            }
            else
            {
                Scopes.Add(new Scope(start, end, 0, currentindex));
            }
        }


        static void RemoveScope(Scope CurrentScope)
        {
            int layer = CurrentScope.Layer;
            for (int i = Scopes.Count - 1; i > -1; i--)
            {
                if (Scopes[i].Layer >= layer)
                {
                    for (int x = 0; x < CurrentScope.Variables.Count; x++)
                    {
                        for (int y = 0; y < Scopes[i].Variables.Count; y++)
                        {
                            if (Scopes[i].Variables[y].Name == CurrentScope.Variables[x].Name)
                            {
                                Scopes[i].Variables[y] = CurrentScope.Variables[x].Copy();
                            }
                        }
                    }
                }
                else if (Scopes[i].Layer + 1 >= layer)
                {
                    for (int x = 0; x < CurrentScope.Variables.Count; x++)
                    {
                        for (int y = 0; y < Scopes[i].Variables.Count; y++)
                        {
                            if (Scopes[i].Variables[y].Name == CurrentScope.Variables[x].Name)
                            {
                                Scopes[i].Variables[y] = CurrentScope.Variables[x].Copy();
                            }
                        }
                    }
                    break;
                }
            }
            ProgramIndex=CurrentScope.OldIndex;
            Scopes.Remove(CurrentScope);
        }


        static void LoadFileIntoProgramData()
        {
            if (DebugOut)
            {
                Console.WriteLine("Loading File into ProgramData");
            }
            ProgramData = new List<(string data, CommandType type)>();
            int index = 0;
            StringBuilder temp = new StringBuilder();
            while (index < FileData.Length)
            {
                if ("; (){}\n\t".Contains(FileData[index]))
                {
                    ProgramData.Add((temp.ToString(), CommandType.Undefined));
                    temp = new StringBuilder();
                    switch (FileData[index])
                    {
                        case ';':
                            ProgramData.Add((";", CommandType.Semicolon));
                            break;
                        case '\t':
                            ProgramData.Add((" ", CommandType.Tab));
                            break;
                        case '(':
                            ProgramData.Add(("(", CommandType.RoundBracketOpen));
                            break;
                        case ')':
                            ProgramData.Add((")", CommandType.RoundBracketClose));
                            break;
                        case '{':
                            ProgramData.Add(("{", CommandType.ScopeOpen));
                            break;
                        case '}':
                            ProgramData.Add(("}", CommandType.ScopeClose));
                            break;
                        case '\n':
                            ProgramData.Add(("", CommandType.NewLine));
                            break;
                    }
                }
                else if (FileData[index] == '\"')
                {
                    ProgramData.Add((temp.ToString(), CommandType.Undefined));
                    temp = new StringBuilder();
                    index++;
                    while (FileData[index] != '\"' && index < FileData.Length)
                    {
                        temp.Append(FileData[index]);
                        index++;
                    }
                    ProgramData.Add((temp.ToString(), CommandType.@string));
                    temp = new StringBuilder();
                }
                else
                {
                    temp.Append(FileData[index]);
                }

                index++;
            }

            for (index = 0; index < ProgramData.Count; index++)
            {
                if (ProgramData[index].type == CommandType.Undefined)
                {
                    if (ProgramData[index].data == "")
                    {
                        ProgramData.RemoveAt(index);
                        index--;
                    }
                    else if (int.TryParse(ProgramData[index].data, NumberStyles.Integer, CultureInfo.InvariantCulture, out int _))
                    {
                        ProgramData[index] = (ProgramData[index].data, CommandType.@int);
                    }
                    else if (float.TryParse(ProgramData[index].data, NumberStyles.Float, CultureInfo.InvariantCulture, out float _))
                    {
                        ProgramData[index] = (ProgramData[index].data, CommandType.@float);
                    }
                }
            }





            for (index = 0; index < ProgramData.Count; index++)
            {
                if (ProgramData[index].type == CommandType.Undefined)
                {
                    if (Commands.CommandList.ContainsKey(ProgramData[index].data))
                    {
                        ProgramData[index] = (ProgramData[index].data, CommandType.Instruction);
                        for (int i = 0; i < Commands.CommandList[ProgramData[index].data].Count; i++)
                        {
                            if (ProgramData[index + Commands.CommandList[ProgramData[index].data][i].Item1].type == CommandType.Undefined)// || ProgramData[index + Commands.CommandList[ProgramData[index].data][i].Item1].type == CommandType.Value)
                            {
                                ProgramData[index + Commands.CommandList[ProgramData[index].data][i].Item1] = (ProgramData[index + Commands.CommandList[ProgramData[index].data][i].Item1].data, Commands.CommandList[ProgramData[index].data][i].Item2);
                            }
                            else
                            {
                                if (ProgramData[index + Commands.CommandList[ProgramData[index].data][i].Item1].type == Commands.CommandList[ProgramData[index].data][i].Item2 || Commands.CommandList[ProgramData[index].data][i].Item2 == CommandType.Value)
                                {

                                }
                                else
                                {
                                    if (DebugOut)
                                    {
                                        int index2 = index + Commands.CommandList[ProgramData[index].data][i].Item1;
                                        if (DebugOut)
                                            Console.WriteLine($"Invalid Datatype! {ProgramData[index2].data} ({ProgramData[index2].type}) is not {Commands.CommandList[ProgramData[index].data][i].Item2} - at block {index + Commands.CommandList[ProgramData[index].data][i].Item1}");


                                        while (index2 > 1 && ProgramData[index2].type != CommandType.Semicolon && ProgramData[index2].type != CommandType.NewLine)
                                        {
                                            index2--;
                                        }
                                        index2++; 
                                        if (DebugOut)
                                            Console.Write("Data: ");
                                        while (index2 < ProgramData.Count && ProgramData[index2].type != CommandType.Semicolon && ProgramData[index2].type != CommandType.NewLine)
                                        {
                                            if (DebugOut)
                                                Console.Write(ProgramData[index2].data + " ");
                                            index2++;
                                        }
                                        if (index2 < ProgramData.Count)
                                        {
                                            if (DebugOut)
                                                Console.Write(ProgramData[index2].data + " ");
                                            index2++;
                                        }
                                        if (DebugOut)
                                            Console.WriteLine();


                                    }
                                }
                            }
                        }
                    }
                }
            }


            ScopePoints = new SortedDictionary<int, int>();
            for (index = 0; index < ProgramData.Count; index++)
            {
                if (ProgramData[index].type == CommandType.Value)
                {
                    if (ProgramData[index].data[0] == '$')
                    {
                        ProgramData[index] =(ProgramData[index].data.Substring(1, ProgramData[index].data.Length-1), CommandType.VariableName);
                    }
                }
                if (ProgramData[index].type == CommandType.ScopeOpen)
                {
                    if (DebugOut)
                        Console.WriteLine($"Finding Scope End {index}");
                    int start = index;
                    int end = start;
                    int layer = 1;
                    index++;
                    while (layer > 0 && index < ProgramData.Count)
                    {
                        //Console.WriteLine($"test - {ProgramData[index].type} {index}");
                        if (ProgramData[index].type == CommandType.ScopeOpen)
                        {
                            layer++;
                        }
                        if (ProgramData[index].type == CommandType.ScopeClose)
                        {
                            layer--;
                        }
                        index++;
                    }
                    if (layer <= 0)
                    {
                        end = index;
                        if (DebugOut)
                            Console.WriteLine($"- SCOPE {start}-{end}");
                        ScopePoints.Add(start, end);
                    }
                    index = start;
                }
            }


            if (DebugOut)
            {
                Console.WriteLine("ProgramData:");
                foreach ((string data, CommandType type) x in ProgramData)
                {
                    Console.Write($"<{x.type},{x.data}>");
                }
            }
        }

        public static Variable GetVariablefromName(string name)
        {
            for (int i = 0; i < ActiveScope.Variables.Count; i++)
            {
                if (ActiveScope.Variables[i].Name == name)
                {
                    return ActiveScope.Variables[i];
                }
            }

            return null;
        }


        static void Main(string[] args)
        {
            DebugOut = false;
            Commands.Init();
            if (args.Length > 0)
            {
                if (DebugOut)
                {
                    Console.WriteLine($"Opening File: {args[0]}");
                }
                FileData = File.ReadAllText(args[0]);
                FileData = FileData.Replace(Environment.NewLine, "\n");
                //Console.WriteLine($"Filedata (Length: {FileData.Length}):");
                //Console.WriteLine(FileData);
                Run();
            }
            else
            {
                Console.WriteLine("ERROR: No File Opened with!");
            }




            Console.WriteLine("----------------------------------------\nEnd.");
            Console.ReadLine();
        }
    }
}
